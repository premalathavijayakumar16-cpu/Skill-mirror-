# SkillMirror — Student Skill Discovery Prototype

SkillMirror is a beginner-friendly website prototype that helps students explore practical strengths through short, real-world challenges.

## Features
- Responsive landing page
- Four sample challenges: logic, design, teamwork, and JavaScript
- Interactive answer feedback
- Skill dashboard that updates after challenges
- Evidence portfolio showing completed activities
- Suggested next steps for continued learning

## Built with
- HTML
- CSS
- JavaScript

## Run locally
1. Download or extract the project folder.
2. Open `index.html` in a web browser.
3. Select a challenge and submit an answer.

No installation or database is required for this demo. Progress is stored only while the page is open and will reset when the page is refreshed.

## Publish with GitHub Pages
1. Create a public GitHub repository named `SkillMirror`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository's root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. After GitHub Pages finishes publishing, it will show your website URL.

## Project limitation
This is a prototype for demonstrating the idea. It does not have user accounts, a database, or validated AI-based assessment. The sample feedback is rule-based and educational, not a formal measurement of a student's abilities.
