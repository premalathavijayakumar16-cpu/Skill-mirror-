const state = {
  completed: {},
  skills: { problem: 20, critical: 15, creative: 10, team: 10, code: 10, communication: 10 }
};

const challenges = {
  logic: {
    title: "The missing number",
    prompt: "What number comes next in this sequence: 2, 4, 8, 16, __?",
    options: ["18", "24", "32", "20"],
    correct: 2,
    explanation: "Correct! Each number is multiplied by 2. You used pattern recognition and logical reasoning.",
    skill: "problem",
    label: "The missing number",
    points: 12
  },
  design: {
    title: "Improve a campus space",
    prompt: "Your college study area is crowded and noisy. Which is the best first step?",
    options: ["Close the study area", "Ask students about their needs, then plan quiet zones and seating", "Buy decorations immediately", "Do nothing until next year"],
    correct: 1,
    explanation: "Good choice! Understanding users' needs before designing a solution shows creativity and practical problem-solving.",
    skill: "creative",
    label: "Improve a campus space",
    points: 12
  },
  team: {
    title: "Plan a team activity",
    prompt: "Your team has one week to organise a campus clean-up. What will help most?",
    options: ["Let one person do everything", "Start without a plan", "Divide tasks, agree on a schedule, and check progress together", "Wait until the last day"],
    correct: 2,
    explanation: "Correct! Sharing responsibilities and checking progress are useful collaboration and planning skills.",
    skill: "team",
    label: "Plan a team activity",
    points: 12
  },
  code: {
    title: "Fix the code",
    prompt: "You want JavaScript to display 'Hello'. Which line is correct?",
    options: ["print('Hello');", "console.log('Hello');", "echo 'Hello';", "show('Hello');"],
    correct: 1,
    explanation: "Correct! console.log() writes a message to the browser's developer console. This demonstrates basic programming knowledge.",
    skill: "code",
    label: "Fix the code",
    points: 12
  }
};

function startChallenge(key) {
  const challenge = challenges[key];
  const area = document.getElementById("challengeArea");
  if (state.completed[key]) {
    area.classList.remove("hidden");
    area.innerHTML = `<h3>${challenge.title}</h3><p>You have already completed this demo challenge.</p><div class="feedback">${challenge.explanation}</div>`;
    area.scrollIntoView({ behavior: "smooth", block: "nearest" });
    return;
  }
  const choices = challenge.options.map((option, i) =>
    `<label class="answer-option"><input type="radio" name="answer" value="${i}"><span>${option}</span></label>`
  ).join("");
  area.innerHTML = `
    <h3>${challenge.title}</h3>
    <p>${challenge.prompt}</p>
    <form id="answerForm"><div class="answer-options">${choices}</div>
      <button class="primary-btn" type="submit">Submit answer →</button>
    </form><div id="feedbackArea"></div>`;
  area.classList.remove("hidden");
  area.scrollIntoView({ behavior: "smooth", block: "nearest" });
  document.getElementById("answerForm").addEventListener("submit", event => {
    event.preventDefault();
    const chosen = document.querySelector('input[name="answer"]:checked');
    const feedbackArea = document.getElementById("feedbackArea");
    if (!chosen) {
      feedbackArea.innerHTML = '<div class="feedback">Choose an answer before submitting.</div>';
      return;
    }
    const correct = Number(chosen.value) === challenge.correct;
    state.completed[key] = { correct, label: challenge.label };
    if (correct) {
      state.skills[challenge.skill] = Math.min(100, state.skills[challenge.skill] + challenge.points);
      state.skills.critical = Math.min(100, state.skills.critical + 5);
      state.skills.communication = Math.min(100, state.skills.communication + 3);
      feedbackArea.innerHTML = `<div class="feedback"><strong>Nice work!</strong> ${challenge.explanation}<br>Your demo skill profile has been updated.</div>`;
    } else {
      feedbackArea.innerHTML = `<div class="feedback"><strong>Good attempt!</strong> Review the options and try to understand the reasoning. ${challenge.explanation}</div>`;
    }
    updateDashboard();
    const submit = document.querySelector('#answerForm button[type="submit"]');
    submit.disabled = true;
    submit.textContent = "Challenge completed";
    submit.style.opacity = ".65";
  });
}

function setBar(id, value) {
  const el = document.getElementById(id);
  if (el) el.style.width = `${value}%`;
}
function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = `${value}%`;
}
function updateDashboard() {
  const s = state.skills;
  const values = Object.values(s);
  const overall = Math.round(values.reduce((sum, n) => sum + n, 0) / values.length);
  document.getElementById("overallScore").textContent = overall;
  setBar("problemBar", s.problem); setBar("problemBar2", s.problem); setText("problemText", s.problem);
  setBar("criticalBar", s.critical); setBar("criticalBar2", s.critical); setText("criticalText", s.critical);
  setBar("creativeBar", s.creative); setText("creativeText", s.creative);
  setBar("teamBar", s.team); setText("teamText", s.team);
  setBar("codeBar", s.code); setText("codeText", s.code);
  setBar("communicationBar", s.communication); setBar("communicationBar2", s.communication); setText("communicationText", s.communication);
  const list = document.getElementById("evidenceList");
  const done = Object.entries(state.completed);
  if (!done.length) {
    list.innerHTML = '<div class="empty-state">No challenges completed yet.<br>Choose one above to begin.</div>';
  } else {
    list.innerHTML = done.map(([key, result]) =>
      `<div class="evidence-item"><div class="evidence-check">${result.correct ? "✓" : "↻"}</div><div><strong>${result.label}</strong><small>${result.correct ? "Completed · answer correct" : "Completed · review recommended"}</small></div></div>`
    ).join("");
  }
}
document.querySelectorAll("[data-challenge]").forEach(button => {
  button.addEventListener("click", () => startChallenge(button.dataset.challenge));
});
document.getElementById("resetBtn").addEventListener("click", () => {
  state.completed = {};
  state.skills = { problem: 20, critical: 15, creative: 10, team: 10, code: 10, communication: 10 };
  document.getElementById("challengeArea").classList.add("hidden");
  document.getElementById("challengeArea").innerHTML = "";
  updateDashboard();
});
updateDashboard();
